﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class Form1 : Form
    {
        clsClientesVentas cliente = new clsClientesVentas();
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cliente.IdCliente = Convert.ToInt32(textBox1.Text);
            cliente.Nombres = textBox2.Text;
            cliente.Apellidos = textBox3.Text;
            cliente.NIT = textBox6.Text;
            cliente.Direccion = textBox4.Text;
            cliente.Municipio = textBox5.Text;

        }
    }
}

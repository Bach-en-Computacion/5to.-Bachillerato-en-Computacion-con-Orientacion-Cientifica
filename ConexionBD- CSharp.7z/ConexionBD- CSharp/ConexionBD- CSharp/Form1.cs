﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionBD__CSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void alumnoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.alumnoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.colegioDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'colegioDataSet.Alumno' Puede moverla o quitarla según sea necesario.
            this.alumnoTableAdapter.Fill(this.colegioDataSet.Alumno);

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.alumnoTableAdapter.Insertar(nombreTextBox.Text, apellidoTextBox.Text, direcciónTextBox.Text, telefonoTextBox.Text);
            this.alumnoTableAdapter.Fill(this.colegioDataSet.Alumno);
            nombreTextBox.Clear(); apellidoTextBox.Clear(); direcciónTextBox.Clear(); telefonoTextBox.Clear();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.alumnoTableAdapter.Buscar(this.colegioDataSet.Alumno, nombreTextBox.Text);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.alumnoTableAdapter.Eliminar(nombreTextBox.Text);
            this.alumnoTableAdapter.Fill(this.colegioDataSet.Alumno);
        }
    }
}

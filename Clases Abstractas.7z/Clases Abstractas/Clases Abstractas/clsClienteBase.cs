﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_Abstractas
{
    public class clsClienteBase : clsAbsClientes
    {
        public clsClienteBase()
        {
            IdCliente = 0;
            Nombre = string.Empty;
            NIT = string.Empty;
            TipoRegimen = 0;
            NombreCompleto = string.Empty;

        }

        public clsClienteBase(int pIdCliente, string pNombre, string pNIT, int pTipoRegimen, string pNombreCompleto)
        {
            IdCliente = pIdCliente;
            Nombre = pNombre;
            NIT = pNIT;
            TipoRegimen = pTipoRegimen;
            NombreCompleto = pNombreCompleto;

        }

        public override int IdCliente { get; set; }

        public override string Nombre { get; set; }

        public override string NIT { get; set; }

        public override int TipoRegimen { get; set; }

        public override string NombreCompleto { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_Abstractas
{
    public abstract class clsAbsClientes
    {
        public abstract int IdCliente { get; set; }

        public abstract string Nombre { get; set; }

        public abstract string  NIT { get; set; }

        public abstract int TipoRegimen { get; set; }

        public abstract string  NombreCompleto { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculo_Salarial
{
    public class clsEmpleados
    {
        public clsEmpleados()
        {
            Nombre = "";
            SueldoDiario = 0.0m;
            Edad = 0;
            DiasTrabajados = 0;
        }

        private string _Nombre;

        private decimal _SueldoDiario;

        private int _Edad;

        private int _DiasTrabajados;

        public string Nombre { get => _Nombre; set => _Nombre = value; }
        public decimal SueldoDiario { get => _SueldoDiario; set => _SueldoDiario = value; }

        public int Edad { get => _Edad ; set => _Edad = value; }
        public int DiasTrabajados { get => _DiasTrabajados; set => _DiasTrabajados = value; }

        public decimal CalculoSalarial(int DiasTrabajados, decimal SueldoDiario)
        {
            return SueldoDiario * DiasTrabajados;
        }
    }
}

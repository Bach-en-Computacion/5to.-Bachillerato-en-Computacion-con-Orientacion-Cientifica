﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_Salarial
{
    public partial class Form1 : Form
    {
        clsEmpleados empleados = new clsEmpleados();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            empleados.Nombre = textBox1.Text;
            empleados.SueldoDiario = Convert.ToDecimal(textBox2.Text);
            empleados.Edad = Convert.ToInt16(textBox3.Text);
            empleados.DiasTrabajados = Convert.ToInt16(textBox4.Text);


            decimal total = 0.0m;

            total = empleados.CalculoSalarial(empleados.DiasTrabajados,empleados.SueldoDiario);

            MessageBox.Show("El salario mensual del empleado es: Q. " + total.ToString());

            textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear();
        }
    }
}
